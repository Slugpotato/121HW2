package com.dealfaro.luca.clicker;

/**
 * Created by ilaforces1 on 4/28/15.
 */
public class MsgInfo {
    public MsgInfo() {};

    String msg;
    String dest;
    String userid;
    String msgid;
    String ts;
}
