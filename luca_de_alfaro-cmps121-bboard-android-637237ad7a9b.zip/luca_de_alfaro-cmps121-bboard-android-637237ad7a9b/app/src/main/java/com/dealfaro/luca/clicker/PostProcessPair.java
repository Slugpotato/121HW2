package com.dealfaro.luca.clicker;

public class PostProcessPair {
    PostProcessPair() {};
    public ServerCallSpec spec;
    public String result;
}
