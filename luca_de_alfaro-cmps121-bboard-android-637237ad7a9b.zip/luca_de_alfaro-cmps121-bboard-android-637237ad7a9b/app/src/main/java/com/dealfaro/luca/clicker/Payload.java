package com.dealfaro.luca.clicker;

/**
 * Created by luca on 3/4/2015.
 */
public class Payload {

    public Payload() {}

    // Account
    public String account;

    // Latitude
    public double lat;

    // Longitude
    public double lng;

    // Accuracy
    public double accuracy;

    // Time
    public String timeStamp;
}
